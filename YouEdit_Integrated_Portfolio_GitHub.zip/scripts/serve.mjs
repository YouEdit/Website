import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../dist');
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.xml':'application/xml','.txt':'text/plain'};
const port=Number(process.env.PORT||4173);
http.createServer(async(req,res)=>{
  let url;
  try{url=new URL(req.url,'http://localhost');}catch{res.writeHead(400);res.end();return;}
  const requestPath=decodeURIComponent(url.pathname);
  let file=path.resolve(root,'.'+requestPath);
  if(!file.startsWith(root+path.sep)&&file!==root){res.writeHead(403);res.end();return;}
  try{let st=await fs.stat(file);if(st.isDirectory())file=path.join(file,'index.html');}
  catch{file=path.join(root,'404.html');res.statusCode=404;}
  try{let data=await fs.readFile(file);res.setHeader('content-type',types[path.extname(file)]||'application/octet-stream');res.end(data);}
  catch{res.writeHead(404);res.end('Not Found');}
}).listen(port,()=>console.log(`Preview: http://localhost:${port}`));
