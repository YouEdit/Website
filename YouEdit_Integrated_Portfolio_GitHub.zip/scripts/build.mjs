import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUT=path.join(ROOT,'dist');
const site=JSON.parse(await fs.readFile(path.join(ROOT,'content/site.json'),'utf8'));
const works=JSON.parse(await fs.readFile(path.join(ROOT,'content/works.json'),'utf8'));
const esc=(v='')=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const cleanUrl=(value='')=>/^https:\/\//i.test(value)?String(value):'';
const slugPattern=/^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const asset=(v)=> /^\/assets\/img\/[\w-]+\.(?:svg|webp|png|jpg|jpeg)$/.test(v||'')?v:'/assets/img/og-cover.svg';
const normalSite=cleanUrl(site.url).replace(/\/$/,'');
if(!normalSite)throw Error('content/site.json の url に https:// で始まるURLを設定してください');
if(!Array.isArray(works)) throw Error('works.json must be an array');
const found=new Set();
for(const w of works){
  if(!slugPattern.test(w.slug))throw Error('作品slugは半角英数字とハイフンのみ: '+w.slug);
  if(found.has(w.slug))throw Error('重複slug: '+w.slug);
  found.add(w.slug);
  if(w.youtubeUrl && !parseYouTube(w.youtubeUrl))throw Error('YouTube URLが不正です: '+w.title);
}
function parseYouTube(raw){
 try {const u=new URL(raw);const host=u.hostname.replace(/^www\./,'');let id='';
 if(host==='youtube.com' || host==='m.youtube.com'){id=u.pathname==='/watch'?u.searchParams.get('v'):(u.pathname.match(/^\/(?:shorts|embed)\/([\w-]+)/)||[])[1];}
 if(host==='youtu.be')id=u.pathname.split('/')[1];
 return /^[\w-]{11}$/.test(id||'')?id:'';
 }catch{return ''}
}
function link(url, label, cssClass='', attrs=''){return `<a href="${esc(url)}" class="${esc(cssClass)}" ${attrs}>${label}</a>`}
function external(url,label,cls='text-link'){return url?link(url,label,cls,'target="_blank" rel="noopener noreferrer"'):'';}
const socialLinks=[
 ['Instagram',cleanUrl(site.instagram)],['YouTube',cleanUrl(site.youtubeChannel)]
].filter(([,v])=>v);
const arrow='<span aria-hidden="true">↗</span>';
const roll='<span class="brand-mark" aria-hidden="true">✳</span>';
const mediaFor=(w)=>{const id=parseYouTube(w.youtubeUrl);if(w.poster&&w.poster!=='auto')return {src:asset(w.poster),isGraphic:w.poster.endsWith('.svg')};if(id)return {src:`https://i.ytimg.com/vi/${id}/maxresdefault.jpg`,fallback:`https://i.ytimg.com/vi/${id}/hqdefault.jpg`,isGraphic:false};return {src:'/assets/img/og-cover.svg',isGraphic:true}};
function header(active=''){
 const nav=[['/','HOME'],['/works/','WORKS'],['/about/','ABOUT'],['/contact/','CONTACT']];
 return `<a class="skip-link" href="#main">本文へ移動</a><header class="site-header" id="site-header"><div class="header-inner container-wide">
 <a href="/" class="wordmark" aria-label="YouEdit ホームへ">You<span>Edit</span><i></i></a>
 <a class="header-note" href="/about/">INDEPENDENT CREATIVE COLLECTIVE<br>BASED IN JAPAN</a>
 <button class="menu-toggle" type="button" aria-label="メニューを開く" aria-expanded="false" aria-controls="site-nav"><span></span><span></span></button>
 <nav class="main-nav" id="site-nav" aria-label="メインナビゲーション">${nav.map(([href,name])=>`<a href="${href}" ${name===active?'aria-current="page"':''}>${name}</a>`).join('')}</nav></div></header>`;
}
function footer(){
 return `<footer class="site-footer"><div class="container-wide"><div class="footer-top"><div><a href="/" class="footer-brand">YouEdit<span class="footer-period">.</span></a><p>映像から、その先へ。</p></div><a class="footer-contact" href="/contact/">GET IN TOUCH <span aria-hidden="true">↗</span></a></div><div class="footer-bottom"><p>© ${new Date().getFullYear()} YouEdit. All rights reserved.</p><div class="footer-social">${socialLinks.map(([name,url])=>external(url,esc(name),'footer-small-link')).join('')}<a class="footer-small-link" href="/privacy/">PRIVACY</a></div><a href="#main" class="footer-top-link" aria-label="ページ先頭へ">↑ TOP</a></div></div></footer>`;
}
function seo(title, description, pathname='/', opts={}){
 const canonical=normalSite+pathname;
 const metaTitle=title?`${title} | YouEdit`:'YouEdit — Creative Collective';
 const image=normalSite+'/assets/img/og-cover.png';
 return `<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
 <meta name="theme-color" content="#0E1110"><meta name="color-scheme" content="dark">
 <title>${esc(metaTitle)}</title><meta name="description" content="${esc(description)}">
 <link rel="canonical" href="${esc(canonical)}"><meta name="robots" content="${opts.noindex?'noindex, nofollow':'index, follow, max-image-preview:large'}">
 <meta property="og:type" content="website"><meta property="og:site_name" content="YouEdit"><meta property="og:title" content="${esc(metaTitle)}"><meta property="og:description" content="${esc(description)}"><meta property="og:url" content="${esc(canonical)}"><meta property="og:image" content="${esc(image)}"><meta name="twitter:card" content="summary_large_image">
 <link rel="icon" type="image/svg+xml" href="/assets/img/mark.svg">
 <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
 <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&family=Noto+Sans+JP:wght@400;500;600;700&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="/assets/css/style.css"><script src="/assets/js/app.js" defer></script>`;
}
function layout({title='',description,pathname='/',active='',body='',bodyClass='',noindex=false}){
 return `<!doctype html><html lang="ja"><head>${seo(title,description,pathname,{noindex})}</head><body class="${esc(bodyClass)}">${header(active)}<main id="main">${body}</main>${footer()}</body></html>`;
}
function eyebrow(index,label){return `<p class="eyebrow"><span class="eyebrow-number">${esc(index)}</span><span class="eyebrow-line"></span>${esc(label)}</p>`}
function workCard(w,i,{extraClass=''}={}){
 const media=mediaFor(w);const safeCat=esc(w.category||'Film');
 return `<a class="work-card ${extraClass}" href="/works/${esc(w.slug)}/" data-categories="${safeCat}" aria-label="${esc(w.title)} の作品詳細を見る">
  <div class="work-image"><img src="${esc(media.src)}" ${media.fallback?`data-fallback="${esc(media.fallback)}"`:''} alt="${esc(w.title)} の${media.isGraphic?'グラフィック画像':'作品サムネイル'}" loading="lazy" width="1000" height="700"><span class="work-overlay"><span>VIEW PROJECT</span><b aria-hidden="true">↗</b></span><span class="work-index">/ ${String(i+1).padStart(2,'0')}</span>${parseYouTube(w.youtubeUrl)?'<span class="work-video-label">▶ VIDEO</span>':''}</div>
  <div class="work-meta"><div><h3>${esc(w.title)}</h3><p>${esc(w.subtitle)}</p></div><span>${safeCat}</span></div></a>`;
}
function workFilters(){
 const values=[...new Set(works.flatMap(w=>String(w.category||'').split('/').map(t=>t.trim()).filter(Boolean)))];
 return `<div class="portfolio-tools" role="group" aria-label="作品カテゴリーで絞り込む"><div class="portfolio-filters"><button type="button" class="portfolio-filter is-active" data-filter="all" aria-pressed="true">ALL</button>${values.map(v=>`<button type="button" class="portfolio-filter" data-filter="${esc(v)}" aria-pressed="false">${esc(v)}</button>`).join('')}</div><p class="portfolio-count" role="status" aria-live="polite"><span data-works-count>${works.length}</span> PROJECTS</p></div>`;
}

function hero(){
 return `<section class="hero" aria-labelledby="hero-title"><div class="hero-grain" aria-hidden="true"></div><div class="container-wide hero-grid">
 <div class="hero-topline"><span class="micro-dot"></span> AN INDEPENDENT CREATIVE COLLECTIVE <span class="hero-line"></span> EST. 2026</div>
 <div class="hero-titles"><p class="hero-pretitle">The story is still unfolding.</p><h1 id="hero-title"><span>YOU</span><span class="hero-second">EDIT<span class="hero-period">.</span></span></h1><p class="hero-japanese">${esc(site.heroJapanese)}</p></div>
 <div class="hero-lower"><p>DEFINED BY WHAT WE MAKE.<br>NOT BY WHAT WE CALL OURSELVES.</p><a class="round-scroll" href="#selected" aria-label="制作実績までスクロール">↓</a></div>
 <div class="hero-side" aria-hidden="true"><span>01 / 04</span><span>SCROLL TO EXPLORE</span></div></div><div class="hero-gridline" aria-hidden="true"></div></section>`;
}
function featuredPlayer(){
 const id=/^[\w-]{11}$/.test(site.featuredYoutubeId||'')?site.featuredYoutubeId:'';
 if(!id)return '';
 return `<section class="feature-film" aria-labelledby="featured-label"><div class="container-wide"><div class="section-header compact-header">${eyebrow('02','IN MOTION')}<p>PLAY / PAUSE / REPLAY</p></div>
 <div class="featured-player-wrap"><button class="video-poster" type="button" data-youtube="${esc(id)}" aria-label="YouTube映像を再生する"><span class="video-background" style="background-image:linear-gradient(180deg,rgba(9,12,11,.08),rgba(9,12,11,.65)),url('https://i.ytimg.com/vi/${esc(id)}/hqdefault.jpg')"></span><span class="video-scope" aria-hidden="true"><span></span><span></span><span></span><span></span></span><span class="video-play" aria-hidden="true">▶</span><span class="video-footer"><span>FEATURED FILM</span><span>WATCH ON SITE ↗</span></span></button></div>
 <div class="featured-caption"><span class="muted-label">A MOMENT IN MOTION</span><p>${esc(site.featuredVideoCaption||'公式サイト掲載映像')}</p><a href="https://www.youtube.com/watch?v=${esc(id)}" target="_blank" rel="noopener noreferrer" class="text-link">YouTubeで開く ↗</a></div>
 </div></section>`;
}
const indexBody=`${hero()}
<section class="section works-preview" id="selected"><div class="container-wide"><div class="section-header">${eyebrow('01','SELECTED WORKS')}<div class="section-title-row"><h2>What we've <em>made.</em></h2><a class="inline-arrow" href="/works/">ALL WORKS <span aria-hidden="true">↗</span></a></div></div>
<div class="work-grid">${works.filter(w=>w.featured).slice(0,4).map((w,i)=>workCard(w,i)).join('')}</div><div class="after-grid"><span>AN ONGOING COLLECTION OF WHAT WE CREATE.</span><a href="/works/" class="pill-link">EXPLORE WORKS <span aria-hidden="true">↗</span></a></div></div></section>
${featuredPlayer()}
<section class="about-teaser section"><div class="container-wide about-teaser-grid"><div>${eyebrow('03','WHO WE ARE')}<span class="big-asterisk" aria-hidden="true">✳</span></div><div class="about-teaser-content"><h2>${esc(site.aboutLead)}</h2><p>${esc(site.aboutText)}</p><a href="/about/" class="pill-link light">MORE ABOUT US <span aria-hidden="true">↗</span></a></div></div></section>
<section class="closing-section"><div class="container-wide">${eyebrow('04','STAY CONNECTED')}<p>HAVE SOMETHING<br><i>IN MIND?</i></p><a href="/contact/" aria-label="お問い合わせページへ" class="closing-circle">↗</a></div></section>`;
const workBody=`<section class="page-intro container-wide"><div class="page-serial">INDEX / 01 — ARCHIVE</div>${eyebrow('01','PORTFOLIO')}<h1>Selected <em>works.</em></h1><div class="page-intro-bottom"><p>これまでに形にしてきたものを、ここに。<br>YouEditの作品を、このサイトで直接見られるアーカイブ。</p><span>${String(works.length).padStart(2,'0')} PROJECTS</span></div></section>
<section class="works-index section"><div class="container-wide">${workFilters()}<div class="work-grid works-grid-full" id="portfolio-grid">${works.map((w,i)=>workCard(w,i)).join('')}</div><p class="portfolio-empty" id="portfolio-empty" hidden>該当する作品はありません。</p><div class="archive-footer"><span>AN ARCHIVE OF WHAT WE MAKE, AND WHAT COMES NEXT.</span><a href="/contact/" class="pill-link">GET IN TOUCH <span aria-hidden="true">↗</span></a></div></div></section>
${featuredPlayer()}`;

const aboutBody=`<section class="page-intro container-wide about-page-intro"><div class="page-serial">INDEX / 02 — IDENTITY</div>${eyebrow('01','ABOUT US')}<h1>Never <em>static.</em><br>Always <em>making.</em></h1><div class="page-intro-bottom"><p>${esc(site.aboutLead)}</p><span>YOUEDIT / CREATIVE COLLECTIVE</span></div></section>
<section class="about-statement section"><div class="container-wide"><div class="about-statement-grid">${eyebrow('02','THE COLLECTIVE')}<div><p class="statement-big">私たちは、何者かを急いで決めない。</p><p class="statement-body">${esc(site.aboutText)}<br><br>目の前の景色や人に向き合い、記録し、編集し、つくる。その積み重ねが、YouEditの輪郭になっていくと考えています。</p></div></div></div></section>
<section class="manifest section"><div class="container-wide">${eyebrow('03','IN A FEW WORDS')}<div class="manifest-list"><div><span>01</span><h2>OBSERVE</h2><p>よく見ること。</p></div><div><span>02</span><h2>CREATE</h2><p>形にすること。</p></div><div><span>03</span><h2>EXPLORE</h2><p>決めつけないこと。</p></div></div></div></section>
<section class="about-bottom"><div class="container-wide"><span class="vertical-tag">AN OPEN-ENDED STORY</span><h2>We're still<br><em>becoming.</em></h2><a href="/contact/" class="pill-link light">SAY HELLO <span aria-hidden="true">↗</span></a></div></section>`;
const contactBody=`<section class="page-intro container-wide contact-intro"><div class="page-serial">INDEX / 03 — CONNECTION</div>${eyebrow('01','CONTACT')}<h1>Let's <em>talk.</em></h1><div class="page-intro-bottom"><p>新しいアイデア、コラボレーション、ちょっとしたご連絡まで。<br>気軽にメッセージをお寄せください。</p><span>OPEN FOR CONVERSATION</span></div></section>
<section class="contact-content"><div class="container-wide contact-grid"><div class="contact-aside">${eyebrow('02','CONNECT')}<h2>Every idea<br>starts somewhere.</h2><p>お送りいただいた内容を確認して、必要に応じて折り返しご連絡します。</p><div class="email-block"><span>DIRECT EMAIL</span><a href="mailto:${esc(site.email)}">${esc(site.email)} ↗</a></div><div class="contact-social">${socialLinks.map(([name,url])=>external(url,esc(name)+' ↗','text-link')).join('')}</div></div>
<div class="contact-form-box"><form name="contact" method="POST" action="/thanks/" data-netlify="true" netlify-honeypot="bot-field" class="contact-form"><input type="hidden" name="form-name" value="contact"><p class="hidden-field"><label>入力しないでください <input name="bot-field" tabindex="-1" autocomplete="off"></label></p>
<div class="form-row"><div class="form-field"><label for="sender-name">YOUR NAME <span>*</span></label><input id="sender-name" name="name" type="text" placeholder="お名前" autocomplete="name" maxlength="100" required></div><div class="form-field"><label for="sender-email">EMAIL ADDRESS <span>*</span></label><input id="sender-email" name="email" type="email" placeholder="your@email.com" autocomplete="email" maxlength="200" required></div></div>
<div class="form-field"><label for="subject">SUBJECT <span>*</span></label><input id="subject" name="subject" type="text" placeholder="お問い合わせの件名" maxlength="180" required></div>
<div class="form-field"><label for="message">MESSAGE <span>*</span></label><textarea id="message" name="message" placeholder="メッセージをご入力ください" rows="7" maxlength="5000" required></textarea></div>
<label class="agreement"><input type="checkbox" required name="privacy-consent" value="agree"><span><a href="/privacy/" target="_blank" rel="noopener noreferrer">プライバシーポリシー</a>を確認し、問い合わせ情報の取り扱いに同意します。</span></label>
<button class="send-button" type="submit"><span>SEND MESSAGE</span><span aria-hidden="true">↗</span></button><p class="form-hint">* は必須項目です。送信はNetlify Formsを利用します。</p></form></div></div></section>`;
const privacyBody=`<section class="page-intro container-wide legal-head">${eyebrow('—','PRIVACY')}<h1>Privacy <em>policy.</em></h1></section>
<section class="legal-content container-wide"><h2>1. 取得する情報</h2><p>お問い合わせフォームでは、お名前、メールアドレス、件名、お問い合わせ内容を取得します。</p><h2>2. 利用目的</h2><p>取得した情報は、お問い合わせへの回答および必要なご連絡のために使用します。</p><h2>3. 外部サービス</h2><p>フォーム送信にはNetlify Forms、動画表示にはYouTube、フォント表示にはGoogle Fontsを利用する場合があります。各サービスによるデータの取り扱いは、それぞれのプライバシーポリシーをご確認ください。</p><h2>4. 管理・削除</h2><p>情報の取り扱いや削除についてのお問い合わせは、<a href="mailto:${esc(site.email)}">${esc(site.email)}</a> までご連絡ください。</p><h2>5. 方針の変更</h2><p>本方針は、必要に応じて内容を見直す場合があります。</p><p class="legal-updated">最終更新：2026年10月</p></section>`;
const thanksBody=`<section class="thanks-page container-wide">${eyebrow('✓','MESSAGE SENT')}<h1>Thank <em>you.</em></h1><p>お問い合わせを受け付けました。<br>内容を確認のうえ、必要に応じてご連絡いたします。</p><a class="pill-link light" href="/">BACK TO HOME ↗</a></section>`;
const notFound=`<section class="thanks-page container-wide">${eyebrow('—','PAGE NOT FOUND')}<h1>404<span class="period">.</span></h1><p>ページが見つかりませんでした。</p><a href="/" class="pill-link light">BACK TO HOME ↗</a></section>`;
const pages=[
 ['index.html',layout({description:'YouEditは映像を起点に活動するクリエイティブチーム。作品と活動の記録を紹介する公式サイトです。',pathname:'/',active:'HOME',body:indexBody,bodyClass:'home-page'})],
 ['works/index.html',layout({title:'Works',description:'YouEditがこれまでに制作した映像作品のアーカイブ。',pathname:'/works/',active:'WORKS',body:workBody,bodyClass:'works-page'})],
 ['about/index.html',layout({title:'About',description:'YouEditについて。映像を起点に、表現の可能性を探るクリエイティブチームです。',pathname:'/about/',active:'ABOUT',body:aboutBody,bodyClass:'about-page'})],
 ['contact/index.html',layout({title:'Contact',description:'YouEditへのお問い合わせ。アイデア、コラボレーション、その他のご連絡はこちらから。',pathname:'/contact/',active:'CONTACT',body:contactBody,bodyClass:'contact-page'})],
 ['privacy/index.html',layout({title:'Privacy Policy',description:'YouEditの個人情報の取り扱いについて。',pathname:'/privacy/',body:privacyBody,bodyClass:'privacy-page'})],
 ['thanks/index.html',layout({title:'Thank You',description:'送信完了',pathname:'/thanks/',body:thanksBody,noindex:true,bodyClass:'thanks-layout'})],
 ['404.html',layout({title:'404',description:'ページが見つかりません',pathname:'/404/',body:notFound,noindex:true,bodyClass:'thanks-layout'})],
];
for(const w of works){
 const hasVideo=Boolean(parseYouTube(w.youtubeUrl));
 const ytId=parseYouTube(w.youtubeUrl);
 const intro=`<section class="project-intro container-wide"><a class="back-link" href="/works/">← BACK TO WORKS</a><div class="project-serial">PROJECT / ${esc(w.year||'—')} <span>${esc(w.category)}</span></div><h1>${esc(w.title)}</h1><div class="project-intro-meta"><p>${esc(w.subtitle||'')}</p><span>PRODUCED BY ${esc(w.credit||'YouEdit')}</span></div></section>`;
 const preview=mediaFor(w);
 const picture=`<img src="${esc(preview.src)}" ${preview.fallback?`data-fallback="${esc(preview.fallback)}"`:''} alt="${esc(w.title)} の${preview.isGraphic?'グラフィック画像':'作品サムネイル'}" width="1000" height="700">`;
 const media=hasVideo?`<section class="project-media container-wide"><div class="project-video-main"><button class="video-poster" type="button" data-youtube="${esc(ytId)}" data-video-title="${esc(w.title)}" aria-label="${esc(w.title)} のYouTube動画を再生"><span class="video-background" style="background-image:linear-gradient(180deg,rgba(9,12,11,.12),rgba(9,12,11,.5)),url('https://i.ytimg.com/vi/${esc(ytId)}/hqdefault.jpg')"></span><span class="video-play" aria-hidden="true">▶</span><span class="video-footer"><span>PLAY FILM</span><span>YOUTUBE ↗</span></span></button></div></section>`:`<section class="project-media container-wide">${picture}${preview.isGraphic?'<span class="image-disclaimer">PROJECT VISUAL / GRAPHIC</span>':''}</section>`;
 const gallery=(Array.isArray(w.gallery)?w.gallery:[]).filter(v=>typeof v==='string'&&/^\/assets\/img\/[\w-]+\.(?:svg|png|jpg|jpeg|webp)$/.test(v));
 const galleryHtml=gallery.length?`<section class="project-gallery container-wide" aria-label="${esc(w.title)} ギャラリー">${gallery.map((src,i)=>`<img src="${esc(src)}" alt="${esc(w.title)} のギャラリー画像 ${i+1}" loading="lazy">`).join('')}</section>`:'';
 const description=`<section class="project-description container-wide"><div>${eyebrow('—','THE PROJECT')}<p class="project-label">${esc(w.category)} / ${esc(w.year||'')}</p></div><div><h2>${esc(w.subtitle||w.title)}</h2><p>${esc(w.description||'')}</p><div class="project-links">${external(cleanUrl(w.youtubeUrl),'WATCH ON YOUTUBE ↗','pill-link')}</div></div></section>${galleryHtml}<div class="project-next container-wide"><span>BACK TO THE ARCHIVE</span><a href="/works/">ALL WORKS ↗</a></div>`;
 pages.push([`works/${w.slug}/index.html`,layout({title:w.title,description:w.description||w.subtitle,pathname:`/works/${w.slug}/`,active:'WORKS',body:intro+media+description,bodyClass:'project-page'})]);
}
await fs.rm(OUT,{recursive:true,force:true});await fs.mkdir(OUT,{recursive:true});
for(const [filename,content] of pages){const filenameAbs=path.join(OUT,filename);await fs.mkdir(path.dirname(filenameAbs),{recursive:true});await fs.writeFile(filenameAbs,content,'utf8');}
await fs.cp(path.join(ROOT,'assets'),path.join(OUT,'assets'),{recursive:true});
const urls=pages.filter(([p])=>p!=='404.html' && !p.startsWith('thanks/')).map(([p])=>normalSite+'/'+(p==='index.html'?'':p.replace(/index\.html$/,'')));
const sitemap=`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.map(u=>`\n<url><loc>${esc(u)}</loc></url>`).join('')}\n</urlset>\n`;
await fs.writeFile(path.join(OUT,'sitemap.xml'),sitemap);
await fs.writeFile(path.join(OUT,'robots.txt'),`User-agent: *\nAllow: /\nSitemap: ${normalSite}/sitemap.xml\n`);
console.log(`Built ${pages.length} pages into dist/ (${works.length} projects)`);
