# YouEdit — 公式サイト + ポートフォリオ 統合版

**GitHub + Netlifyで公開できる、追加の有料CMS不要の静的ウェブサイトです。**
旧foriioポートフォリオを削除した後でも、YouEdit公式サイト内のWORKSページ・作品詳細ページは動作します。動画本体はYouTubeを埋め込み再生します（YouTubeで動画が公開されていることが必要）。

## 収録内容

- HOME：YouEditのブランド紹介と注目作品、ピックアップ動画
- WORKS：**公式サイト内に統合されたポートフォリオ**。カテゴリー切り替え、作品一覧、各作品の個別ページ、YouTube再生。
- ABOUT：チーム紹介
- CONTACT：Netlify Formsのお問い合わせフォーム
- PRIVACY：個人情報の取扱いに関する初期案
- `tools/works-editor.html`：**作品をGUIで編集し、YouTube URLを一括追加できるローカル編集ツール**

**foriioへのリンクや、foriioが公開している画像・埋め込み・APIには依存しません。**

## 現在の作品データについて（重要）

現在の `content/works.json` には、これまでの会話から確認できる以下の2件が登録されています。

- CUCINA CONTENTO
- すずき蓮根農園

サムネイルには仮の独自グラフィックを使用しています。YouTube URLは正確に確認できなかったため、**空欄のまま**です。各詳細ページは現時点では画像と文章のみ表示します。

また、以前の公式サイトに掲載していた動画ID `Ghl7nvLUo7c` は `content/site.json` の `featuredYoutubeId` に引き継いであり、HOMEとWORKSにピックアップ再生枠があります。動画のタイトル・公開状況は未検証です。必要なら実際のリンクに差し替えてください。

**現在のforiioの全掲載作品や各YouTube URLは自動取得できていません。全作品の移行が完了したとはみなさないでください。**

## 旧foriioポートフォリオを削除する前の手順

1. foriioにログインし、**全作品の一覧、タイトル、紹介文、サムネイル、制作クレジット、YouTube元動画URL**を控える。可能なら作品ページをPDFで保存するかスクリーンショットも残す。
2. YouTube上で動画が公開されていること（限定公開も埋め込み可能な場合あり）、他者の動画なら埋め込みの許可があることを確認する。
3. 下記の編集ツールから、作品を公式サイトに追加する。foriioの作品ページURLではなく、**YouTube動画URL**を使う。
4. GitHubからNetlifyにデプロイ後、すべての作品詳細ページを開き、動画・タイトル・画像・文章を確認する。
5. Google検索で見つかっていたforiioの作品ページURLなどは、閉鎖すると失われます。旧サイトの検索評価を新サイトへ自動移管することはできません。必要ならforiioのプロフィール欄で公式サイトへ誘導してから閉鎖する。
6. **全作品の移行と動作確認が終わるまでforiioを削除しない。**

## 作品の一括追加・編集（プログラミング不要）

1. `tools/works-editor.html` をブラウザで開く。インターネット不要。
2. 「works.jsonを読み込む」で `content/works.json` を開く。
3. **1件ずつ編集**するか、「YouTube作品をまとめて追加」欄に次の形式で貼り付ける：

   ```text
   作品タイトル | https://www.youtube.com/watch?v=XXXXXXXXXXX | Documentary
   作品タイトル | https://youtu.be/YYYYYYYYYYY | Food / Film
   ```

   パイプ記号 `|` で区切り、1行1作品です。URLが重複している場合は取り込みません。

4. 作品を選んで詳しい説明・カテゴリー・制作年・サムネイル・クレジットを編集。上下ボタンで順序も変更できます。YouTube URLと画像パスがあればページに反映されます。
5. 「編集内容をJSONで保存」でダウンロードした `works.json` を、GitHubの `content/works.json` に上書きする。
6. GitHubで「Commit changes」を押すと、Netlifyで自動再デプロイされます。

### 実際のサムネイルを使う場合

1. 自分たちが権利を持つ写真や動画サムネイルをWebP/JPG/PNGに変換する。
2. GitHubの `assets/img/` にアップロードする。
3. 編集ツールの「画像パス」に `/assets/img/画像名.webp` と記入。
4. ギャラリーに追加する場合は「写真ギャラリー」に同じ形式の画像パスを**1行1枚**記入。

`poster` を空欄にして有効なYouTube URLを登録した場合は、YouTubeの動画サムネイルを自動で表示します。外部通信を避けたい場合は自分の画像を登録してください。

## GitHubとNetlifyでの公開

1. GitHubでリポジトリ（例：`youedit-site`）を新規作成。
2. GitHub用ZIPを解凍し、**フォルダの中身**（`package.json`、`content/`、`assets/`、`scripts/`など）をGitHubのルートにアップロード。
3. Netlifyの `Add new project` → `Import an existing project` からGitHubの該当リポジトリを選択。
4. `netlify.toml` が自動設定します。
   - Build command：`npm run build`
   - Publish directory：`dist`
   - Node version：22
5. デプロイ完了後、HOME、WORKS、個別作品、ABOUT、CONTACTをチェックする。
6. 以前の `you-edit.netlify.app` を引き継ぐ場合は、Netlifyの既存サイトのリポジトリ接続を変更するなどして**元のサイトを置き換える**。切り替え前にバックアップを取る。
7. 正式URLを変更した場合は `content/site.json` の `url` も変更し再デプロイする。ここからcanonicalやサイトマップが生成されます。

`dist/` はビルドで生成されます。GitHub用ZIPには `dist/` を含めていません。Netlifyへのドラッグ＆ドロップ用ZIPはビルド済みの `dist/` 内のファイルが入っています。

## お問い合わせフォーム

`CONTACT` のフォームはNetlify Forms向けに実装済み。Netlifyデプロイ後にFormsの管理画面でフォーム `contact` が検出されていることを確認し、通知メールを設定してください。**必ずテスト送信**をしてください。ローカルでは送信できません。

`content/site.json` の `email` は `info@you-edit.com` に設定されています。実際に受信できるメールアドレスか確認し、必要に応じて修正してください。

## SEO / 検索

Google検索での表示を保証するものではありません。全ページのHTMLをビルド時に生成し、`sitemap.xml`、`robots.txt`、canonical、各作品詳細ページの個別タイトル・説明を用意しています。Netlifyで公開後、Google Search Consoleでサイトを登録してサイトマップを送信してください。

## ローカル動作確認

Node.js 18以上で以下を実行。追加のnpm依存ライブラリはありません。

```bash
npm run build
npm run start
```

ブラウザで `http://localhost:4173/` を開く。

## データ構造

`content/works.json` の1作品例：

```json
{
  "slug": "project-001",
  "title": "作品タイトル",
  "subtitle": "短い説明",
  "category": "Documentary / Film",
  "year": "2026",
  "description": "作品の背景と制作について",
  "poster": "",
  "youtubeUrl": "https://www.youtube.com/watch?v=XXXXXXXXXXX",
  "credit": "YouEdit",
  "featured": true,
  "gallery": ["/assets/img/scene1.webp", "/assets/img/scene2.webp"]
}
```

- `slug`：重複しない半角英数字とハイフン。生成URLは `/works/slug/`。
- `featured`：トップページのおすすめ作品に表示するか。
- `youtubeUrl`：URLがある場合のみ埋め込み再生ボタンが表示されます。YouTube動画が削除されたり再生・埋め込みを禁止されると動かなくなります。
- `poster`：空欄ならYouTubeのサムネイル（動画未設定なら汎用グラフィック）。
- `gallery`：追加画像のローカルパス（任意）。
- `externalUrl`：旧foriioへの依存をなくすため廃止。

**サイト掲載の事実関係、問い合わせ先、動画・画像の権利関係は公開前にご確認ください。**
