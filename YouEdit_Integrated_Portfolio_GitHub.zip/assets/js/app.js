(() => {
  'use strict';
  const toggle=document.querySelector('.menu-toggle');
  const header=document.querySelector('.site-header');
  const nav=document.querySelector('.main-nav');
  if(toggle && header && nav){
    const close=()=>{header.classList.remove('nav-open');toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-label','メニューを開く');};
    toggle.addEventListener('click',()=>{
      const open=toggle.getAttribute('aria-expanded')==='true';
      if(open)close();else{header.classList.add('nav-open');toggle.setAttribute('aria-expanded','true');toggle.setAttribute('aria-label','メニューを閉じる');}
    });
    nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',close));
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&toggle.getAttribute('aria-expanded')==='true'){close();toggle.focus();}});
    document.addEventListener('click',e=>{if(header.classList.contains('nav-open')&&!header.contains(e.target))close();});
  }
  document.querySelectorAll('[data-youtube]').forEach(button=>{
    button.addEventListener('click',()=>{
      const id=button.dataset.youtube;
      if(!/^[\w-]{11}$/.test(id))return;
      const container=document.createElement('div');
      container.className='video-embed';
      const frame=document.createElement('iframe');
      frame.src=`https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1&rel=0`;
      frame.title=button.dataset.videoTitle||'YouEditの制作映像';frame.allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
      frame.referrerPolicy='strict-origin-when-cross-origin';frame.allowFullscreen=true;
      container.append(frame);button.replaceWith(container);
    },{once:true});
  });
  // Filter locally rendered portfolio cards without hiding them when JavaScript is unavailable.
  const filters=[...document.querySelectorAll('[data-filter]')];
  const cards=[...document.querySelectorAll('#portfolio-grid .work-card')];
  const count=document.querySelector('[data-works-count]');
  filters.forEach(button=>button.addEventListener('click',()=>{
    const chosen=button.dataset.filter;
    filters.forEach(b=>{const on=b===button;b.classList.toggle('is-active',on);b.setAttribute('aria-pressed',String(on));});
    let visible=0;
    cards.forEach(card=>{
      const categories=(card.dataset.categories||'').split('/').map(v=>v.trim());
      const show=chosen==='all'||categories.includes(chosen);
      card.hidden=!show;if(show)visible++;
    });
    if(count)count.textContent=String(visible);
    const empty=document.getElementById('portfolio-empty');if(empty)empty.hidden=visible!==0;
  }));
  // If high-resolution YouTube thumbnails are absent, automatically use standard resolution.
  document.querySelectorAll('img[data-fallback]').forEach(img=>{
    img.addEventListener('error',()=>{const src=img.dataset.fallback;if(src && img.src!==src){img.removeAttribute('data-fallback');img.src=src;}},{once:true});
  });
})();
